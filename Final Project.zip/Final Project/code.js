var Definition  = getColumn("Musicology", "Definition ");
//citation: information by https://www.britannica.com/art/guitar
//Citation: information by website: https://www.vocabulary.com/dictionary/bass
//citation: information by website: https://www.britannica.com/art/drum-musical-instrument
var pic = getColumn("Musicology", "Picture");
//citation: Guitar Picture by Petr Kratochvil (https://www.publicdomainpictures.net/en/view-image.php?image=2173&picture=acoustic-guitar)
//citation: Bass Picture provide by https://cdn.britannica.com/97/237297-050-874869DA/Fender-P-Bass-electric-guitar.jpg?w=400&h=300&c=crop
var output = 0;
var conic = getColumn("Musicology", "congratulations");
//Citation: Background picture by BulingBuling (Pngtree.com)
//citation for congratulating picture: https://t3.ftcdn.net/jpg/02/33/38/08/360_F_233380815_4ah3nJszftXDiCch6CwlmlAJdJSsRlSM.jpg
//https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-JXyzuwlT_yMVF4P0ltg7vXT5_638VhYONrlo_V1VVJ7Yh4F65ydvNcBoclph21th4oI&usqp=CAU
//https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQp0K3hJ-eadtovDUeOf97vBW4d4iOICY8BlNzVgzubUcEAYQtUZZWpUWWMMMxASZs5pQ&usqp=CAU 

//citation for setting: https://wallpapertag.com/wallpaper/middle/1/7/8/197192-musical-background-1920x1080-photos.jpg


//Variable for test,score,and chance countdown.
var correct = ["Guitar", "guitar", "Bass", "bass", "Drum", "drum"];
var chance;
var score = 0;
var chance = 5;
var display = ["Score: ", " Chance: "] ;

setText("test1", "Test");
setText("home", "Start");
setText("back", "Back");
setText("back1", "Back");
setText("back2", "Back");
setText("setting", "Setting");
setText("next", "Next");


onEvent("backhome", "click", function( ) {
  setScreen("homescreen");
});


//for Introduction page
onEvent("setting", "click", function( ) {
  setScreen("settingscreen");
  hideElement("Music");
  showElement("button3");
});
//Space For guitar
onEvent("home", "click", function( ) {
  output = getText("text_input1");
  setText("label2", "Please Section one " + output);
  setScreen("secondscreen");
  if (output==0) {
    setScreen("homescreen");
  }
});



onEvent("guitar", "click", function( ) {
  setScreen("guitarscreen");
  setText("guitardoc", Definition[0]);
  setImageURL("guitarpng", pic[0]);
});


onEvent("back", "click", function( ) {
  home();
});

onEvent("next", "click", function( ) {
  setScreen("bassscreen");
  setText("text_area3", Definition [1]);
  setImageURL("image2", pic[1]);
});



//Space for setting screen
onEvent("setting", "click", function( ) {
  setScreen("settingscreen");
  hideElement("Music");
  showElement("button3");
});
onEvent("button3", "click", function( ) {
  playSound("assets/Lukas_Graham_Love_Someone_8D_AUDIO_.mp3", true);
  showElement("Music");
  hideElement("button3");
});
onEvent("Music", "click", function( ) {
  stopSound("assets/Lukas_Graham_Love_Someone_8D_AUDIO_.mp3");
  showElement("button3");
  hideElement("Music");
});
onEvent("back4", "click", function( ) {
  setScreen("homescreen");
});

//Fail Screen
onEvent("button5", "click", function( ) {
  setScreen("secondscreen");
});
onEvent("failback", "click", function( ) {
  setScreen("homescreen");
});



//space for Bass
onEvent("bass", "click", function( ) {
  setScreen("bassscreen");
  setText("text_area3", Definition [1]);
  setImageURL("image2", pic[1]);
});
onEvent("back1", "click", function( ) {
  home();
});
onEvent("next2", "click", function( ) {
  setScreen("drumscreen");
  setText("drumdoc", Definition[2]);
  setImageURL("image1", pic[2]);
});






//Space for Drum
onEvent("drum", "click", function( ) {
  setScreen("drumscreen");
  setText("drumdoc", Definition[2]);
  setImageURL("image1", pic[2]);
});
onEvent("back2", "click", function( ) {
  home();
});
onEvent("next1", "click", function( ) {
  setScreen("test");
  setImageURL("guitarpic", pic[0]);
});



//space for test
onEvent("test1", "click", function( ) {
  setScreen("test");
  setImageURL("guitarpic", pic[0]);
});



//This Function is for name input and output on a specific location





//back home function
function home() {
  setScreen("secondscreen");
}

//Quiz Section 
onEvent("button1", "click", function( ) {
  quiz();
});
onEvent("button4", "click", function( ) {
  quiz1();
});
onEvent("button2", "click", function( ) {
  quiz2();
});
//restart score and chance
onEvent("button5", "click", function( ) {
  restart();
});
onEvent("failback", "click", function( ) {
  restart();
});

//this function is to return value
function quiz(total) {
  if (getText("text_input2") == correct[0] ||getText("text_input2") == correct [1]) {
    score = score + 1;
    setScreen("Test2");
    setImageURL("image4", pic[1]);
    setText("label9", display [0] + score);
    setText("label10", display[1] + chance);
  } else {
    chance = chance-1 ;
setText("Test2", display [0] + score);
setText("chancebox", display[1] + chance);
  }
  if (chance==0) {
    setScreen("fail");
    setText("scorebox", display[0] + score);
  }
  return total;
}
function quiz1(total) {
  if (getText("text_input4") == correct[2] ||getText("text_input4") == correct [3]) {
    score = score + 1;
    setScreen("test3");
    setText("label6", display [0] + score);
    setText("test2", display[1] + chance);
    setImageURL("image3", pic[2]);
  } else {
    while (chance -1) {
      setText("scorebox", display [0] + score);
      setText("label10", display[1] + chance);
      setImageURL("image3", pic[2]);
    }
  }
  if (chance==0) {
    setScreen("fail");
  }
  return total;
}
function quiz2(total) {
  if (getText("text_input3") == correct[4] ||getText("text_input3") == correct [5]) {
    score = score + 1;
    setText("totalscore", display [0] + score);
    setImageURL("image5", conic [(randomNumber (0, conic[0]))]);
    setScreen("Total");
  } else {
    chance  = chance -1;
    setText("label6", display [0] + score);
setText("test2", display[1] + chance);
setImageURL("image3", __);
  }
  if (pic[2]==0) {
    setScreen("fail");
  }
  return total;
}
//This function will set the score and chance back to it own value 
function restart() {
  score = 0;
  chance = 5;
}
